require "json"
require "time"
require "ipaddr"
require "date"
require "redis"

# -*- coding: UTF-8 -*-

# class Event
#   def initialize(str)
#     @@obj = JSON.parse(str)
#   end
#   def get(key)
#     @@obj[key]
#   end
#   def set(key,value)
#     @@obj[key]=value
#   end
# end

# global shared variable
$redis_data = ''

#==============================================
def register(params)
  puts "get redis info start from http register xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
  puts params
  puts params["redis_config"]
  redis_config_list = params["redis_config"].split("|") 
  @redis_host = redis_config_list[0]
  @redis_port = redis_config_list[1]
  @redis_pwd = redis_config_list[2]

  puts "get redis info end http register xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
end




def filter(event)

  begin
      @redis_client=Redis.new(:host => @redis_host, :port => @redis_port, :timeout=>60, :password=>@redis_pwd)
      $redis_data = @redis_client.get:"name"
      @redis_client.close

    return []
  rescue
    return []

  end
end

