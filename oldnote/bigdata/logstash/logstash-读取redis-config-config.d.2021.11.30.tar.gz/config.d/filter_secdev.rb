require "json"
require "time"
require "ipaddr"
require "date"
require "redis"

# -*- coding: UTF-8 -*-

# class Event
#   def initialize(str)
#     @@obj = JSON.parse(str)
#   end
#   def get(key)
#     @@obj[key]
#   end
#   def set(key,value)
#     @@obj[key]=value
#   end
# end

#global variable
#$redis_data


def register(params)
  puts "get redis info start from udp register xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
  puts params["redis_config"]
  redis_config_list = params["redis_config"].split("|") 
  @redis_host = redis_config_list[0]
  @redis_port = redis_config_list[1]
  @redis_pwd = redis_config_list[2]

  @redis_client=Redis.new(:host => @redis_host, :port => @redis_port, :timeout=>60, :password=>@redis_pwd)
  $redis_data = @redis_client.get:"name"
  @redis_client.close
  puts $redis_data
  puts "get redis info end udp register xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
end

#==============================================

def process(event)
  secdev_log={"logtype"=>"secdev","ip"=>"0.0.0.0","devtype"=>"",\
              "msg"=>"","sip"=>"0.0.0.0","sport"=>0,"dip"=>"0.0.0.0","dport"=>0,"res"=>"","risk"=>0,"person_info"=>$redis_data,"timestamp"=>"","status"=>0,"block"=>0}

  #正则的业务逻辑

  return secdev_log
end
# ----------------------


def filter(event)
  begin
    log=process(event)
    event.set("data", log)
    return [event]
  rescue
    return []

  end
end

